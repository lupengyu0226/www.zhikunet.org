<?php
return array (
  'identification' => 'nulls',
  'realease' => '20120414',
  'dir' => 'nulls',
  'appid' => '1013',
  //plugin表配置
  'plugin'=> array(
		  'version' => '1.0',
		  'name' => '无效信息提醒',
		  'copyright' => '05273.cn',
		  'description' => '无效信息提醒',
		  'installfile' => 'install.php',
		  'uninstallfile' => 'uninstall.php',
	),
)
?>