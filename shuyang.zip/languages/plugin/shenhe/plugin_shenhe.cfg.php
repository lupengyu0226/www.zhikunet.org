<?php
return array (
  'identification' => 'shenhe',
  'realease' => '20120402',
  'dir' => 'shenhe',
  'appid' => '10001',
  //plugin表配置
  'plugin'=> array(
		  'version' => '1.0',
		  'name' => '待审文章提示',
		  'copyright' => 'shuyang team',
		  'description' => '待审文章提示',
		  'installfile' => 'install.php',
		  'uninstallfile' => 'uninstall.php',
	),
)
?>
