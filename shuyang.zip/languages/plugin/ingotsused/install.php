<?php
defined('IN_SHUYANG') or exit('No permission resources.');	
$op_status = TRUE;
?>
