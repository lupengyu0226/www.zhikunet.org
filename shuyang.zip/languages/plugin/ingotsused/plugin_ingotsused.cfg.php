<?php
return array (
  'identification' => 'ingotsused',
  'realease' => '20161203',
  'dir' => 'ingotsused',
  'appid' => '101911',
  //plugin表配置
  'plugin'=> array(
		  'version' => '1.0',
		  'name' => '春节下金元宝',
		  'copyright' => '05273.cn',
		  'description' => '春节下金元宝，下到初五',
		  'url'=>'http://www.05273.cn/',
		  'installfile' => 'install.php',
		  'uninstallfile' => 'uninstall.php',
	),
)
?>