<?php
return array (
  'identification' => 'phone',
  'realease' => '20160414',
  'dir' => 'phone',
  'appid' => '1016',
  //plugin表配置
  'plugin'=> array(
		  'version' => '1.0',
		  'name' => '便民电话申请提醒',
		  'copyright' => '05273.cn',
		  'description' => '便民电话申请提醒',
		  'installfile' => 'install.php',
		  'uninstallfile' => 'uninstall.php',
	),
)
?>