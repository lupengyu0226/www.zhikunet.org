<?php
return array (
  'identification' => 'fanghu',
  'realease' => '20120414',
  'dir' => 'fanghu',
  'appid' => '10191',
  //plugin表配置
  'plugin'=> array(
		  'version' => '1.0',
		  'name' => '防护提示',
		  'copyright' => '05273.cn',
		  'description' => '防护提示',
		  'installfile' => 'install.php',
		  'uninstallfile' => 'uninstall.php',
	),
)
?>