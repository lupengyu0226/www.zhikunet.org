<?php
return array (
  'identification' => 'pinglun',
  'realease' => '20120414',
  'dir' => 'pinglun',
  'appid' => '10190',
  //plugin表配置
  'plugin'=> array(
		  'version' => '1.0',
		  'name' => '待审评论提示',
		  'copyright' => '05273.cn',
		  'description' => '待审评论提示',
		  'installfile' => 'install.php',
		  'uninstallfile' => 'uninstall.php',
	),
)
?>