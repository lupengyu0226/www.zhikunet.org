<?php
return array (
  'identification' => 'baoliao',
  'realease' => '20120414',
  'dir' => 'baoliao',
  'appid' => '1012',
  //plugin表配置
  'plugin'=> array(
		  'version' => '1.0',
		  'name' => '爆料提醒',
		  'copyright' => '05273.cn',
		  'description' => '爆料提醒',
		  'installfile' => 'install.php',
		  'uninstallfile' => 'uninstall.php',
	),
)
?>