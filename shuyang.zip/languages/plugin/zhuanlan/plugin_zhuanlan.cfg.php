<?php
return array (
  'identification' => 'zhuanlan',
  'realease' => '20171018',
  'dir' => 'zhuanlan',
  'appid' => '10001',
  //plugin表配置
  'plugin'=> array(
		  'version' => '1.0',
		  'name' => '待审专栏审核',
		  'copyright' => 'shuyang team',
		  'description' => '待审专栏审核',
		  'installfile' => 'install.php',
		  'uninstallfile' => 'uninstall.php',
	),
)
?>
