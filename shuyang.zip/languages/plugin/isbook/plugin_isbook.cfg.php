<?php
return array (
  'identification' => 'isbook',
  'realease' => '20120414',
  'dir' => 'isbook',
  'appid' => '1013',
  //plugin表配置
  'plugin'=> array(
		  'version' => '1.0',
		  'name' => '留言提醒',
		  'copyright' => '05273.cn',
		  'description' => '留言提醒',
		  'installfile' => 'install.php',
		  'uninstallfile' => 'uninstall.php',
	),
)
?>