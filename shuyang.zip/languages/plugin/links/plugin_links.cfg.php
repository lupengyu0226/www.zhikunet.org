<?php
return array (
  'identification' => 'links',
  'realease' => '20160414',
  'dir' => 'links',
  'appid' => '1015',
  //plugin表配置
  'plugin'=> array(
		  'version' => '1.0',
		  'name' => '申请友链提醒',
		  'copyright' => '05273.cn',
		  'description' => '申请友链提醒',
		  'installfile' => 'install.php',
		  'uninstallfile' => 'uninstall.php',
	),
)
?>