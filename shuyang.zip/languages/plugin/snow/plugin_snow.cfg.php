<?php
return array (
  'identification' => 'snow',
  'realease' => '20120414',
  'dir' => 'snow',
  'appid' => '101911',
  //plugin表配置
  'plugin'=> array(
		  'version' => '1.0',
		  'name' => '圣诞夜下雪',
		  'copyright' => '05273.cn',
		  'description' => '圣诞来场雪，下到年初一',
		  'url'=>'http://www.05273.cn/',
		  'installfile' => 'install.php',
		  'uninstallfile' => 'uninstall.php',
	),
)
?>