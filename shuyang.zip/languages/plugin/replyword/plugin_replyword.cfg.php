<?php
return array (
  'identification' => 'replyword',
  'realease' => '20120414',
  'dir' => 'replyword',
  'appid' => '101911',
  //plugin表配置
  'plugin'=> array(
		  'version' => '1.0',
		  'name' => '公众号消息提醒',
		  'copyright' => '05273.cn',
		  'description' => '此处显示的是公众号内消息列表',
		  'installfile' => 'install.php',
		  'uninstallfile' => 'uninstall.php',
	),
)
?>