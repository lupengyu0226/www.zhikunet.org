<?php
return array (
  'identification' => 'press',
  'realease' => '20120414',
  'dir' => 'press',
  'appid' => '101912',
  //plugin表配置
  'plugin'=> array(
		  'version' => '1.0',
		  'name' => '稿件处理提醒',
		  'copyright' => '05273.cn',
		  'description' => '此处显示的是稿件处理提醒',
		  'installfile' => 'install.php',
		  'uninstallfile' => 'uninstall.php',
	),
)
?>