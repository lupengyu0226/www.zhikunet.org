<?php

/*Language Format:
Add a new file(.lang.php) with your module name at /shuyang/languages/
translation save at the array:$LANG
*/
$LANG['fanghu']						=	'攻击日志管理';
$LANG['fanghu_list']					=	'攻击日志列表';
$LANG['remove_all_selected']				=	'删除所攻击日志';
$LANG['affirm_delete']					=	'确定删除所选攻击日志?';
$LANG['fanghu_deleted']					=	'删除所选攻击日志成功';
$LANG['fanghu_call']					=	'攻击日志详情';
$LANG['call']					        =	'详细信息';
$LANG['wangzhi']			         	=	'所属网址';
$LANG['ttime']				         	=	'攻击时间';
$LANG['ip']				          	=	'攻击者IP';
$LANG['iparea']				          	=	'攻击者位置';
$LANG['page']					        =	'被攻击页面';
$LANG['method']					        =	'提交方式';
$LANG['rkey']					        =	'使用参数';
$LANG['rdata']					        =	'攻击特征';
$LANG['user_agent']				        =	'客户端信息';
$LANG['request_url']			                =	'具体路径';
?>
