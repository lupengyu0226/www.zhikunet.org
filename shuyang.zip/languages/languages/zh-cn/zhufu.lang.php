<?php

/*Language Format:
Add a new file(.lang.php) with your module name at /shuyang/languages/
translation save at the array:$LANG
*/
$LANG['zhufu']						=	'祝福管理';
$LANG['zhufu_list']					=	'祝福列表';
$LANG['index']					=	'首页访问';
$LANG['remove_all_selected']					=	'删除所选祝福';
$LANG['affirm_delete']					=	'确定删除所选祝福?';
$LANG['zhufu_deleted']					=	'删除所选祝福成功';
?>
