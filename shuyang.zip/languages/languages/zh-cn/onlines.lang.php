<?php

/*Language Format:
Add a new file(.lang.php) with your module name at /shuyang/languages/
translation save at the array:$LANG
*/
$LANG['onlines']						=	'在线用户';
$LANG['onlines_list']					=	'在线用户列表';
$LANG['remove_all_selected']		=	'踢掉';
$LANG['affirm_delete']				=	'确定踢掉?';
$LANG['onlines_deleted']				=	'踢掉所选';
$LANG['onlines_call']					=	'在线详情';
$LANG['call']					    =	'详细信息';
$LANG['userid']			         	=	'举报用户';
$LANG['title']			         	=	'举报标题';
$LANG['url']			         	=	'举报地址';
$LANG['content']			        =	'举报原因';
$LANG['adddate']			        =	'举报时间';
?>
