<?php
$LANG['user_search_word_list'] 					=	'搜索感知';
?>