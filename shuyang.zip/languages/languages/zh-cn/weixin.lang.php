<?php
//接口配置
$LANG['token'] = 'TOKEN';
$LANG['appid'] = 'appid';
$LANG['appsecret'] = 'appsecret';
$LANG['requirements'] = '高配接口配置(必填项)';
$LANG['baserequirements'] = '基础配置(必填项)';
$LANG['weixin_module_configuration'] = '微信公众号接口配置';
$LANG['weixin_menu_add'] = '自定义菜单';
$LANG['weixin_menu_select'] = '菜单查询';

$LANG['weixin_menu'] = '自定义菜单';
//客户管理
$LANG['weixin_add_servicekeyword'] = '添加客服关键词';
//自动回复
$LANG['weixin_reply_addkeyword'] = '添加关键词';
$LANG['weixin_add_arcticle'] = '添加图文';
//关注回复
$LANG['weixin_reply_focus'] = '关注设置';
$LANG['weixin_user_addgroup']='添加分组';
$LANG['weixin_pingtai']='<a target="_blank" href="https://mp.weixin.qq.com/">https://mp.weixin.qq.com/</a>';
//分组管理
$LANG['weixin_tuopiao_add'] = '添加微投票';
?>