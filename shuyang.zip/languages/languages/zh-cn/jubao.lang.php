<?php

/*Language Format:
Add a new file(.lang.php) with your module name at /shuyang/languages/
translation save at the array:$LANG
*/
$LANG['jubao']						=	'内容举报管理';
$LANG['jubao_list']					=	'内容举报列表';
$LANG['remove_all_selected']		=	'删除所举报';
$LANG['affirm_delete']				=	'确定删除所选举报?';
$LANG['jubao_deleted']				=	'删除所选举报成功';
$LANG['jubao_call']					=	'举报详情';
$LANG['call']					    =	'详细信息';
$LANG['userid']			         	=	'举报用户';
$LANG['title']			         	=	'举报标题';
$LANG['url']			         	=	'举报地址';
$LANG['content']			        =	'举报原因';
$LANG['adddate']			        =	'举报时间';
$LANG['jianyi']			        =	'用户建议';
$LANG['status_1'] = '<font color="red">已处理</font>';
$LANG['status_0'] = '<font color="blue">未处理</font>';
?>
