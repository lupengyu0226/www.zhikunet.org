<?php
$LANG['member_init'] = '管理中心';
$LANG['account_manage'] = '账号管理';
$LANG['favorite'] = '收藏';
$LANG['pay'] = '在线充值';
$LANG['论坛'] = '论坛';
$LANG['mall'] = '我要开店';
?>