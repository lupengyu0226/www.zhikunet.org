<?php

//模块安装
$LANG['enable_status'] = '是否开启专栏';
$LANG['zhuanlan_close_status'] = '没有此专栏或被关闭';
$LANG['domain'] = '访问域名';
$LANG['index_urlruleid'] = '专栏首页URL规则';
$LANG['show_urlruleid'] = '专栏作者url';
$LANG['authoremail'] = '支持论坛';
$LANG['regx'] = '格式错误:必须是字母';
$LANG['versionregx'] = '示例:1.0.1';
$LANG['version'] = '版本号';
$LANG['domain_name_format'] = '域名可为空，格式应该为http://www.05273.cn/';
$LANG['domain_end_string'] = '格式应该为http://www.05273.cn/，请以‘/’结束，支持无协议 例如://www.05273.cn/';
$LANG['zhuanlan_name'] = '专栏名称';
$LANG['zhuanlan_domain'] = '自定义域名';
$LANG['zhuanlan_thumb'] = '作家头像';
$LANG['authors'] = '作家简介';
$LANG['status_on'] = '通过';
$LANG['status_off'] = '未通过';
$LANG['createtime'] = '开通时间';
?>