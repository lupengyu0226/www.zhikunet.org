<?php
$LANG['dianping_type_name'] 			=	'类型名称';
$LANG['dianping_type_data'] 			=	'类型内容'; 
$LANG['show_dianping_data'] 			=	'查看数据';
$LANG['delete_select'] 					=	'删除选中';
$LANG['delete_confirm'] 				=	'是否确定删除该记录？';
/*共用*/ 
$LANG['call_code'] 						=	'调取代码';
$LANG['update_dianpingtype'] 			=	'更新分类缓存';
$LANG['dianping_datainfo'] 				=	'分类示例： <font color="red">质量&&价格&&服务</font>,每项以英文 && 分隔。';

/*后台*/

$LANG['dianping_type_id'] 				=	'分类ID';
$LANG['is_guest'] 						=	'是否允许游客点评：';
$LANG['is_check'] 						=	'是否需要审核：';
$LANG['is_code'] 						=	'是否开启验证码：';
$LANG['is_checkuserid'] 				=	'是否验证用户：';
$LANG['add_points'] 					=	'点评积分奖励：';
$LANG['del_points'] 					=	'点评删除扣分：';
$LANG['points_info'] 					=	'分，0为不操作。';

/*调用代码 */
$LANG['call_infos'] 					=	'1、点击复制以下代码，然后把调用代码复制粘贴到需要显示的模板再更新相关网页即可。如不需要检查是否允许会员点评，请修改is_checkuserid=0;';
$LANG['call_info'] 						=	'调用说明：';
$LANG['iframe_call'] 					=	'IFRAME调用';
$LANG['dianping_call_type'] 			=	'点评调用方式';
$LANG['copy_code_use'] 					=	'复制代码至剪贴板';
?>