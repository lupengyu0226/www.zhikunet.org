<?php

/*Language Format:
Add a new file(.lang.php) with your module name at /shuyang/languages/
translation save at the array:$LANG
*/

//index$LANG['setting_succ'] = '配置修改成功';
$LANG['test_email_succ'] = '测试邮件已经成功发送到：';
$LANG['test_email_faild'] = '邮件发送失败';
$LANG['mail_type'] = '邮件发送模式';
$LANG['mail_type_mail'] = 'mail 模块发送';
$LANG['mail_type_smtp'] = 'SMTP 函数发送';
$LANG['mail_server'] = '邮件服务器';
$LANG['mail_port'] = '邮件发送端口';
$LANG['mail_from'] = '发件人地址';
$LANG['mail_auth'] = 'AUTH LOGIN验证';
$LANG['mail_user'] = '验证用户名';
$LANG['mail_password'] = '验证密码';

$LANG['mail_auth_open'] = '开启';
$LANG['mail_auth_close'] = '关闭';

$LANG['mail_test'] = '收件人';
$LANG['mail_test_send'] = '发送';

$LANG['mail_auth_close'] = '关闭';
?>