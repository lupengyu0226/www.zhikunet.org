<?php

/*Language Format:
Add a new file(.lang.php) with your module name at /shuyang/languages/
translation save at the array:$LANG
*/


?>
