<?php
/**
 *   update.php 飞天系统主入口
 *
 * @copyright			(C) 2005-2014 EDI
 * @license				https://www.05273.cn/index.php?app=license
 * @lastmodify			2014-5-16
 */
define('SHUYANG_PATH', dirname(__FILE__).DIRECTORY_SEPARATOR);
include SHUYANG_PATH.'/languages/feitian.php';
shy_base::creat_app();
?>